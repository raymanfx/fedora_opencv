# Object Detection using Convolutional Neural Networks

- These files include model weights, model definition files, model deploy files for two trained networks.

### Network 1
- SqueezeNet model trained on ImageNet 2012 Dataset

### Network 2
- SqueezeDet model trained on PASCAL VOC Dataset
